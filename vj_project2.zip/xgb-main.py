import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import  LabelEncoder
import xgboost as xgb
import numpy as np

st.header("URL type Prediction App-(Bening, Malware, Phishing, Spam)")

df=pd.read_csv('C:\\Users\\vijay\\Desktop\\Python-programs\\multiclass_set_randomized_features_with_whois.csv')

#Predictor Variables
X = df[['Domain_Age','Registrant_Country','use_of_ip','abnormal_url', 'count.', 'count-www', 'count@',
       'count//', 'count_dir', 'count_embed_domian', 'short_url', 'count-https',
       'count-http', 'count%', 'count?', 'count-', 'count=', 'url_length',
       'hostname_length', 'sus_url', 'fd_length', 'tld_length', 'count-digits',
       'count-letters', 'count_comma', 'count*',
       'count+', 'count!','count_quote']]

#Target Variable
y = df['type_code']

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=1)

#Load model
model = xgb.XGBClassifier()
model.load_model("xgb_model.json")

#Feature Engineering
#df1 = pd.DataFrame({'url':[st.text_input('Enter URL to check')], 'Domain_Age': [0], 'Registrant_Country': [1]})
#testin line
input_var=st.text_input('Enter URL to check')

df1data = {'url':input_var}


#whois info collection
from openpyxl import load_workbook
from os.path import exists
import sys
import json
import whois
from datetime import datetime

def getDaysDiff(whoi_info):
 #whoi_info = json.load(whoi_info)
 if('creation_date' in whoi_info and 'expiration_date' in whoi_info):  
  if(isinstance(whoi_info['creation_date'], list) and len(whoi_info['creation_date']) > 0):
    if(whoi_info['creation_date'][0] is None or len(str(whoi_info['creation_date'][0])) == 0):
      return 1
    creationdatetime = str(whoi_info['creation_date'][0]).split()
  else:
    if(whoi_info['creation_date'] is None or len(str(whoi_info['creation_date'])) == 0):
      return 1 
    creationdatetime = str(whoi_info['creation_date']).split()
  if('-' not in creationdatetime and ':' not in creationdatetime): 
    return 1
  cDate = creationdatetime[0].split("-")
  ctime = creationdatetime[1].split(":")
  if(isinstance(whoi_info['expiration_date'], list) and len(whoi_info['expiration_date']) > 0):
    if(whoi_info['expiration_date'][0] is None or len(whoi_info['expiration_date'][0]) == 0):
      return 1
    expdatetime = str(whoi_info['expiration_date'][0]).split() 
  else:
    if(whoi_info['expiration_date'] is None or len(whoi_info['expiration_date']) == 0):
      return 1
    expdatetime = str(whoi_info['expiration_date']).split()
  if('-' not in expdatetime and ':' not in expdatetime):
    return 1   
  eDate = expdatetime[0].split("-")
  etime = expdatetime[1].split(":")  
  creationDate = datetime(int(cDate[0]), int(cDate[1]), int(cDate[2]),  int(ctime[0]), int(ctime[1]), int(ctime[2]))
  expireDate = datetime(int(eDate[0]), int(eDate[1]), int(eDate[2]),  int(etime[0]), int(etime[1]), int(etime[2]))
  print(expireDate)
  print(creationDate)
  tdiff = str(expireDate - creationDate)
  print(f'age is::{tdiff}')
  if(int(tdiff.split()[0]) < 365):
     age = 0
  else:
     age = 1 
  print('age::', age)
  return age
 else:
  return 1  


def registrantFlag(whoi_info):
  #whoi_info = json.load(whoi_info)
  if('country' in whoi_info):
   if(whoi_info['country'] is None or len(whoi_info['country']) == 0):
     return 1
   country = whoi_info['country']
   listcountries = ["CN", "VN", "ES", "RU", "KP", "FA", "WR", "HI"]
   if country in listcountries:
     flag = 0
   else:
     flag = 1  
   print('registrant country::', flag)
   return flag
  else:  
   return 1
   
   
def is_registered(domain_name):
   try:
       d = whois.whois(domain_name)
   except Exception:
       return bool(False)
   else:
       return bool(d.domain_name)   

def main(value):
  print(f'You entered:{value}')
  if(is_registered(value)):
     whoi_info = whois.whois(value)
     #print(f'url res:: {whoi_info}')
     age = getDaysDiff(whoi_info)
     print('age:', age)
     flag = registrantFlag(whoi_info)
     print('country category:',flag)
  else:
     age = 1
     flag = 1
     print('age:', age)
     print('country category:',flag) 
  df1data['Domain_Age']=age
  df1data['Registrant_Country']=flag
  print(df1data)  
      
# Main body
if __name__ == '__main__':
    main(df1data['url'])

df1 = pd.DataFrame(df1data, index=[0])

import re
#Use of IP or not in domain
def having_ip_address(url):
    match = re.search(
        '(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.'
        '([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\/)|'  # IPv4
        '((0x[0-9a-fA-F]{1,2})\\.(0x[0-9a-fA-F]{1,2})\\.(0x[0-9a-fA-F]{1,2})\\.(0x[0-9a-fA-F]{1,2})\\/)' # IPv4 in hexadecimal
        '(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}', url)  # Ipv6
    if match:
        # print match.group()
        return 1
    else:
        # print 'No matching pattern found'
        return 0
df1['use_of_ip'] = df1['url'].apply(lambda i: having_ip_address(i))

from urllib.parse import urlparse

def abnormal_url(url):
    hostname = urlparse(url).hostname
    hostname = str(hostname)
    match = re.search(hostname, url)
    if match:
        # print match.group()
        return 1
    else:
        # print 'No matching pattern found'
        return 0


df1['abnormal_url'] = df1['url'].apply(lambda i: abnormal_url(i))

df1['count.'] = df1['url'].apply(lambda i: i.count('.'))

df1['count-www'] = df1['url'].apply(lambda i: i.count('www'))
df1['count@'] = df1['url'].apply(lambda i: i.count('@'))
df1['count//'] = df1['url'].apply(lambda i: i.count('//'))
df1['count?'] = df1['url'].apply(lambda i: i.count('?'))
df1['count='] = df1['url'].apply(lambda i: i.count('='))
df1['count_comma'] = df1['url'].apply(lambda i: i.count(','))
df1['count*'] = df1['url'].apply(lambda i: i.count('*'))
df1['count+'] = df1['url'].apply(lambda i: i.count('+'))
df1['count!'] = df1['url'].apply(lambda i: i.count('!'))
df1['count%'] = df1['url'].apply(lambda i: i.count('%'))
df1['count-'] = df1['url'].apply(lambda i: i.count('-'))
df1['count_quote'] = df1['url'].apply(lambda i: i.count('"'))
from urllib.parse import urlparse
def no_of_dir(url):
    urldir = urlparse(url).path
    return urldir.count('/')
df1['count_dir'] = df1['url'].apply(lambda i: no_of_dir(i))
def no_of_embed(url):
    urldir = urlparse(url).path
    return urldir.count('//')
df1['count_embed_domian'] = df1['url'].apply(lambda i: no_of_embed(i))
def shortening_service(url):
    match = re.search('bit\.ly|goo\.gl|shorte\.st|go2l\.ink|x\.co|ow\.ly|t\.co|tinyurl|tr\.im|is\.gd|cli\.gs|'
                      'yfrog\.com|migre\.me|ff\.im|tiny\.cc|url4\.eu|twit\.ac|su\.pr|twurl\.nl|snipurl\.com|'
                      'short\.to|BudURL\.com|ping\.fm|post\.ly|Just\.as|bkite\.com|snipr\.com|fic\.kr|loopt\.us|'
                      'doiop\.com|short\.ie|kl\.am|wp\.me|rubyurl\.com|om\.ly|to\.ly|bit\.do|t\.co|lnkd\.in|'
                      'db\.tt|qr\.ae|adf\.ly|goo\.gl|bitly\.com|cur\.lv|tinyurl\.com|ow\.ly|bit\.ly|ity\.im|'
                      'q\.gs|is\.gd|po\.st|bc\.vc|twitthis\.com|u\.to|j\.mp|buzurl\.com|cutt\.us|u\.bb|yourls\.org|'
                      'x\.co|prettylinkpro\.com|scrnch\.me|filoops\.info|vzturl\.com|qr\.net|1url\.com|tweez\.me|v\.gd|'
                      'tr\.im|link\.zip\.net',
                      url)
    if match:
        return 1
    else:
        return 0
df1['short_url'] = df1['url'].apply(lambda i: shortening_service(i))

df1['count-https'] = df1['url'].apply(lambda i : i.count('https'))
df1['count-http'] = df1['url'].apply(lambda i : i.count('http'))

#Length of URL
df1['url_length'] = df1['url'].apply(lambda i: len(str(i)))
#Hostname Length
df1['hostname_length'] = df1['url'].apply(lambda i: len(urlparse(i).netloc))

def suspicious_words(url):
    match = re.search('urgent|bonanza|property|global|PayPal|advice|job|login|online|signin|heipdesk|delivery|bank|account|tax|update|free|lucky|service|bonus|ebayisapi|webscr',
                      url)
    if match:
        return 1
    else:
        return 0
df1['sus_url'] = df1['url'].apply(lambda i: suspicious_words(i))

#First Directory Length
from tld import get_tld
def fd_length(url):
    urlpath= urlparse(url).path
    try:
        return len(urlpath.split('/')[1])
    except:
        return 0

df1['fd_length'] = df1['url'].apply(lambda i: fd_length(i))

#Length of Top Level Domain
df1['tld'] = df1['url'].apply(lambda i: get_tld(i,fail_silently=True))

def tld_length(tld):
    try:
        return len(tld)
    except:
        return -1

df1['tld_length'] = df1['tld'].apply(lambda i: tld_length(i))

def digit_count(url):
    digits = 0
    for i in url:
        if i.isnumeric():
            digits = digits + 1
    return digits
df1['count-digits']= df1['url'].apply(lambda i: digit_count(i))

def letter_count(url):
    letters = 0
    for i in url:
        if i.isalpha():
            letters = letters + 1
    return letters
df1['count-letters']= df1['url'].apply(lambda i: letter_count(i))
df1 = df1.drop("tld",1)

a=df1['Domain_Age'][0]
b=df1['Registrant_Country'][0]
c=df1['use_of_ip'][0]
d=df1['abnormal_url'][0]
e=df1['count.'][0]
f=df1['count-www'][0]
g=df1['count@'][0]
h=df1['count//'][0]
i=df1['count_dir'][0]
j=df1['count_embed_domian'][0]
k=df1['short_url'][0]
l=df1['count-https'][0]
m=df1['count-http'][0]
n=df1['count%'][0]
o=df1['count?'][0]
p=df1['count-'][0]
q=df1['count='][0]
r=df1['url_length'][0]
s=df1['hostname_length'][0]
t=df1['sus_url'][0]
u=df1['fd_length'][0]
v=df1['tld_length'][0]
w=df1['count-digits'][0]
x=df1['count-letters'][0]
y=df1['count_comma'][0]
z=df1['count*'][0]
a1=df1['count+'][0]
a2=df1['count!'][0]
a3=df1['count_quote'][0]

inputs = np.expand_dims([a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,a1,a2,a3],0)

#Load model
model1 = xgb.XGBClassifier()
model1.load_model("xgb_model.json")

if st.button('Make Prediction'):
    prediction = model1.predict(inputs)
    print("final pred", np.squeeze(prediction,-1))
    #st.write(f"This url is:{np.squeeze(prediction,-1)}")
    if np.squeeze(prediction,-1)==0:
        st.write(f"This is a BENING url")
    elif np.squeeze(prediction,-1)==1:
        st.write(f"This is a MALWARE url")
    elif np.squeeze(prediction,-1)==2:
        st.write(f"This is a PHISHING url")
    else:
        st.write(f"This is a SPAM url")


from openpyxl import load_workbook
from os.path import exists
import base64
import sys
import requests
import vt
import time
import json
import asyncio
import nest_asyncio

#nest_asyncio.apply()

def scanreport(scan_id):
  client = vt.Client("ef9d95ef1afc2e4117cfeef67fd43e702dfaeb09bec1cea61e528992e1ed4b48")
  response = ""
  try:
      analysis = client.scan_url(scan_id)
  except ValueError as e:
      print("Rate limit detected:", e)
  except Exception:
      print("Error detected:")
  else:
      #print(f'scan_id::{scan_id}')
      url_id = vt.url_id(scan_id)
      try:
          url = client.get_object("/urls/{}", url_id)
          #print(f'last_analysis_stats: {url.last_analysis_stats}')
      except ValueError as e:
          print("Rate limit detected:", e)
      except Exception:
          print("Error detected:")
      else:
          response = url.last_analysis_stats      
  finally:
      client.close()
  return response

def reportResult(reportval):
  if(reportval['malicious'] == 0 and reportval['suspicious'] == 0):
       return "benign"
  else:
       return "malicious"

def main1(value):

  reportval = scanreport(value)
  print(f'result:: {reportval}')
  return reportval

vir_var=main1(input_var)
if(vir_var is not None and len(vir_var)!=0):
    st.header("VirusTotal Prediction")
    st.write(f"VirusTotal output:",vir_var) 


